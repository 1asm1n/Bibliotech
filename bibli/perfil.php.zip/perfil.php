</html>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
<main class="container">
  <div class="bg-light p-5 rounded">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="editar.php">Editar dados</a>
            </li>
            <li class="nav-item">
                <a class="nav-link disabled" type= "submit">Excluir</a>
            </li>
            <li class="nav-item">
                <a class="nav-link disabled" href="conf.php">Sair</a>
            </li>
        </ul>
    </div>
</main>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>


<?php

    /*session_start();
    include_once("salvar.php");
    include("conexao.php");
    $nome = $_SESSION['nome'];
    $email = $_SESSION['email'];
    $tipo_usuario = $_SESSION['tipo_usuario'];
    $query_usuario = $conectar->query("select nome, email, nomePerfil from usuario u inner join perfil p on (p.codPerfil = u.codPerfil) where nome='$nome[0]'");
    while($sql = $query_usuario->fetch(PDO::FETCH_ASSOC)) {
    echo "<TABLE>
    <tr><td> Nome : $sql[nome]</td></tr> <tr><td> E-mail : $sql[email]</td> <tr><td> Usuário : $sql[nomePerfil]</td></tr>

    </TABLE>";
}
    switch(@$_REQUEST["action"]){
     case "editar":
        include("editar.php");
    break;
        case "Excluir":
        include("");
    break;
        case "Sair":
        include("conf.php");
    break;
}*/

$consulta = $conectar->query("SELECT nome, email, codUsuario
FROM usuario u INNER JOIN perfil as p
ON (p.codPerfil = u.codPerfil)");

echo "<table class='table table-striped'><tr><td><h5>Nome</h5></td> 
    <td><h5>Email</h5></td></tr>";
    while($linha = $consulta->fetch(PDO::FETCH_ASSOC)) {
        
        echo "<tr><td>$linha[nome]</td> <td>
        $linha[email]</td>  <td>
        <a href='gravar.php?id=$linha[codUsuario]'>Editar</a> /td></tr>";
    }

    echo "</table>";

?>
</body>
</html>
